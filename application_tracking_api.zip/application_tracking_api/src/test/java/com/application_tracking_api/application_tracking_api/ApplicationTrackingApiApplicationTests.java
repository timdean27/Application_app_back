package com.application_tracking_api.application_tracking_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApplicationTrackingApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
